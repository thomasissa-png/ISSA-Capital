# Qui est Thomas Issa

## Identité

**Thomas Issa** — entrepreneur, investisseur, fondateur. Né en 1986, vit à **Nanterre (92)** avec sa conjointe Nathalie Kervarec et leurs 5 enfants. Issu d'une famille d'origine libanaise — Jean-Pierre Issa (ex-IBM, équipe fondatrice Lexmark Europe, Co-Managing Director 2J Impression) et Sonia Issa (architecte d'intérieur).

## Famille

### Parents
- **Jean-Pierre Issa** — père. Né à Dakar (1958), famille libanaise. IBM → Lexmark Europe → 2J Impression (Mérignac). Figure fondatrice patrimoniale.
- **Sonia Issa** — mère. Née au Caire (1959), famille libanaise. Architecte d'intérieur.

### Sœur
- **Nathalie Issa** — née en 1988

### Conjointe
- **Nathalie Kervarec** — née le 3 novembre 1986. Conjointe de Thomas.

### Enfants (famille recomposée — 5 enfants au total)
- **Antoine Issa** — né le 24 avril 2015 (fils de Thomas et Leslie Guerin)
- **Naomie Kervarec** — née en 2015 (fille de Nathalie Kervarec, union précédente)
- **Noémie Issa** — née le 18 décembre 2018 (fille de Thomas et Leslie Guerin)
- **Nolan Kervarec** — né en 2018 (fils de Nathalie Kervarec, union précédente)
- **Lucas Issa** — né le 5 mars 2023 (fils de Thomas et Nathalie Kervarec)

### Usage copy / publication
- **Ne JAMAIS publier** les noms des enfants, dates de naissance, ou détails familiaux sur un site ou un contenu public sans validation explicite de Thomas
- Sur les sites vitrines : utiliser "trois enfants" ou "la génération à venir" — pas de prénoms
- Ce fichier est un référentiel interne pour que Claude comprenne le contexte familial, pas un contenu à publier

## Parcours international

Paris (1986-1993) → **Afrique du Sud** (1994-1998) → Paris (1999-2002) → Suisse / Lycée Florimont, Genève (2002-2004, baccalauréat) → retour France. Cette trajectoire multicontinentale nourrit une vision globale et une aisance interculturelle naturelle.

## Formation

- **Classe préparatoire** — Sainte-Geneviève, Versailles (2004-2006)
- **IMT Atlantique** (ex-Télécom Bretagne) — ingénieur (2006-2008)
- **Altran** — conseil en ingénierie (2009)
- **IMT Atlantique** — ingénieur d'affaires (2009-2010)
- **UC Irvine** — échange international, Californie (2010)
- **HEC Paris** — Master Marketing (2010-2011)

## Parcours professionnel

1. **Gartner** (2011-2012) — analyse et conseil IT
2. **Sony** (2012-2015) — fonctions de direction. Distinctions : Exceptional Contribution Award x2, Best Sony Europe 2014
3. **TEOS** — fondateur. Bâtie de zéro en moins d'un an, déployée dans sept régions du monde, 0 à 8 M€ de CA en 4 ans
4. **Agence de communication internationale** (2020) — fondateur. Montée sur fonds propres jusqu'à 3,5 M€ de CA, 40 experts. Clients : Adidas, Lego, TikTok, Sony. Revendue avec succès. [CONFIDENTIEL — ne pas mentionner le nom de l'agence ni le montant de cession sans accord Thomas]
5. **Advisor startups** — accompagnement sélectif de fondateurs et dirigeants
6. **Gradient One** (2020) — co-fondateur avec Carl Standertskjold-Nordenstam et Maxime Lemoine. Holding intermédiaire
7. **Versi** (2022) — co-fondateur. Écosystème immobilier intégré (Versi Immobilier, Versi Invest, Versi Capital, Versi Finance)
8. **ISSA Capital** (2026) — Président et fondateur. Holding patrimoniale familiale (SAS, Nanterre). Patrimoine familial, horizon intergénérationnel, zéro capitaux tiers

## Distinctions

- Major de promotion x3
- Exceptional Contribution Award Sony x2
- Best Sony Europe 2014

## Langues

- Français — natif
- Anglais — bilingue (parcours international US/Afrique du Sud)
- Allemand — professionnel limité
- Arabe — élémentaire (héritage familial libanais)

## Vision et convictions

On a qu'une vie. Thomas se donne les moyens d'en profiter et de faire profiter les siens.

Tout le reste en découle : les opérations court terme qui génèrent de la trésorerie, le patrimoine long terme qui sécurise la famille, les associés avec qui il choisit de travailler, les secteurs dans lesquels il refuse d'aller.

Ce qu'il construit doit pouvoir être transmis à ses enfants.

## Sites web

- **issa-capital.com** — holding patrimoniale familiale
- **versi.fr** — écosystème immobilier intégré
- **versi-immobilier.fr** — marchand de biens, Hauts-de-France
- **versi-invest.fr** — co-investissement immobilier

## Réseau clé

- **Carl Standertskjold-Nordenstam** — co-fondateur Versi/Gradient One
- **Maxime Lemoine** — co-fondateur Versi/Gradient One, responsable immobilier
- **Emmanuel Gomez** — ex-Président Gradient One, conseiller proche (sans contrat)
- **Martin Yhuel** — avocat associé, PNM Avocats (droit des sociétés, M&A, Lille)
- **Jean-Pierre Issa** — père, figure fondatrice patrimoniale
